### Schoolbox Puppet Dashboard

## Deployment
This application is deployed to sitedev. The deployed files are currently owned by `andy.ryan`. 

There is a crude cron job in the `andy.ryan` crontab running every minute that pulls in the latest code from the repo on the `master` branch.

